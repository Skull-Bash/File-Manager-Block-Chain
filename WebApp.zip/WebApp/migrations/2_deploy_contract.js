var log = artifacts.require("log");

module.exports = function(deployer) {
    deployer.deploy(log);
};